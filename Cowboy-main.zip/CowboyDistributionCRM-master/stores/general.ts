export const useGeneralStore = defineStore("general", () => {
  return {};
});
