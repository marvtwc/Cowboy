/// <reference types="@histoire/plugin-vue/components" />
