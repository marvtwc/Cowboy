<template>
  <div>Successfully generated quote {{ $route.params.quote }}</div>
</template>
