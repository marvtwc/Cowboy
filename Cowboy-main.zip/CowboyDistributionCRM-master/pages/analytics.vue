<script setup lang="ts">
definePageMeta({
  middleware: "auth",
});
</script>
<template>
  <div>
    <BasePageHeader page="Analytics" />
  </div>
</template>
