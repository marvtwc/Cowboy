<script setup lang="ts">
definePageMeta({
  middleware: "auth",
});
import { useEmployeeStore } from "~/stores/employees";
const employeeStore = useEmployeeStore();
const { showCreateDialog } = storeToRefs(employeeStore);
</script>
<template>
  <div>
    <BasePageHeader page="Contractors">
      <button
        @click="showCreateDialog = true"
        class="rounded-sm border border-white/10 bg-blue-600/80 px-6 py-1 text-blue-200 shadow-[0_2px_8px] shadow-blue-500/10"
      >
        Add
      </button>
    </BasePageHeader>
    <div>
      <EmployeeTable />
      <EmployeeCreateDialog />
      <EmployeeEditDialog />
    </div>
  </div>
</template>
