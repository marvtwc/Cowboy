<template>
  <div class="flex min-h-screen justify-center bg-base-600">
    <NuxtPage class="text-white" />
  </div>
</template>
