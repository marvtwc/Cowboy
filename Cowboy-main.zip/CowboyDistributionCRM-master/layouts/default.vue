<template>
  <div class="flex h-screen bg-base-600 text-white">
    <BaseNavbar />
    <NuxtPage class="flex-1 overflow-x-hidden p-4" />
  </div>
</template>
<style scoped>
body,
html {
  height: 100%;
  overflow: hidden;
}
</style>
