const quoteColumns = [ { accessorKey: "_id", header: "Order ID", cell: ({ row })
=> { return h( NuxtLink, { to: `/orders/${row.original._id}` }, { default: () =>
row.original._id, }, ); }, }, { accessorKey: " ", header: "Total Quotes", cell:
({ row }) => { return row.original.quotes.length; }, }, { accessorKey: " ",
header: "Total Invoices", cell: ({ row }) => { return
row.original.invoices.length; }, }, ];
