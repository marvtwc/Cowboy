<script setup lang="ts">
import {
  FlexRender,
  getCoreRowModel,
  useVueTable,
  getSortedRowModel,
  getFilteredRowModel,
} from "@tanstack/vue-table";
import { type ColumnDef } from "@tanstack/table-core";

const props = defineProps({
  data: { type: Array, required: true },
  columns: { type: Array<ColumnDef<unknown, any>>, required: true },
  search: { type: String, default: "" },
  hiddenColumns: { type: Array, default: () => [] },
});

const table = ref({});
const sorting = ref([]);
const expanded = ref([]);
const filter = computed(() => props.search);
initializeTable();
function initializeTable() {
  table.value = useVueTable({
    data: props.data,
    columns: props.columns,
    getCoreRowModel: getCoreRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getSortedRowModel: getSortedRowModel(),
    state: {
      get expanded() {
        return expanded.value;
      },
      get sorting() {
        return sorting.value;
      },
      get globalFilter() {
        return filter.value;
      },
    },
    onSortingChange: (updater) => {
      sorting.value =
        typeof updater === "function" ? updater(sorting.value) : updater;
    },
  });
}

function toggleRowSelected(row) {}

watch(
  props.data,
  () => {
    initializeTable();
  },
  { deep: true },
);
watch(
  () => props.data,
  () => {
    initializeTable();
  },
);
watch(
  () => props.hiddenColumns,
  () => {
    props.hiddenColumns.forEach((column) => {
      table.value.getColumn(column).toggleVisibility(false);
    });
  },
);
</script>
<template>
  <div
    class="overflow-hidden rounded-lg border border-base-500/50 bg-base-default text-base-100 shadow-lg drop-shadow-lg"
  >
    <slot></slot>
    <div class="overflow-x-auto">
      <table class="w-full">
        <thead class="sticky top-0 bg-base-700 text-left">
          <tr
            v-for="headerGroup in table.getHeaderGroups()"
            :key="headerGroup.id"
          >
            <th
              class="px-4 py-2 text-sm font-medium text-base-200"
              v-for="header in headerGroup.headers"
              :key="header.id"
              @click="header.column.getToggleSortingHandler()?.($event)"
            >
              <FlexRender
                :render="header.column.columnDef.header"
                :props="header.getContext()"
              />
              <Icon
                :class="{
                  'rotate-180': header.column.getIsSorted() === 'desc',
                  'rotate-0': header.column.getIsSorted() === 'asc',
                  invisible: !header.column.getIsSorted(),
                }"
                name="mdi:chevron-down"
                class="ml-1 h-4 w-4"
              />
            </th>
          </tr>
        </thead>
        <tbody v-if="table.getRowModel().rows.length > 0">
          <tr
            v-for="(row, rIndex) in table.getRowModel().rows"
            @click="toggleRowSelected(row.id)"
            :key="row.id"
          >
            <td
              class="border-b border-base-500/50 px-4 py-3"
              v-for="cell in row.getVisibleCells()"
              :key="cell.id"
            >
              <FlexRender
                :render="cell.column.columnDef.cell"
                :props="cell.getContext()"
              />
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    <div
      v-if="table.getRowModel().rows.length === 0"
      class="flex h-full w-full justify-center pt-16"
    >
      <p>No Data</p>
    </div>
  </div>
</template>
