<script setup lang="ts">
const props = defineProps({
  status: String,
});
</script>
<template>
  <div
    :class="{
      'bg-status-accepted-secondary/10 text-status-accepted-primary border-status-accepted-border/35':
        status == 'ACCEPTED',
      'bg-status-rejected-secondary/10 text-status-rejected-primary border-status-rejected-border/35':
        status == 'REJECTED',
      'bg-status-pending-secondary/10 text-status-pending-primary border-status-pending-border/35':
        status == 'PENDING',
      'bg-status-sent-secondary/10 text-status-sent-primary border-status-sent-border/35':
        status == 'SENT',
      'bg-status-notsent-secondary/10 text-status-notsent-primary border-status-notsent-border/35':
        status == 'NOT SENT',
    }"
    class="max-w-[100px] rounded border py-1 text-center text-[10px]"
  >
    {{ status }}
  </div>
</template>
