<script setup lang="ts">
import { toUpperCamelCase } from "~/utils/format";
import {
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuPortal,
  DropdownMenuRoot,
  DropdownMenuTrigger,
} from "radix-vue";

const props = defineProps({
  _id: {
    type: String,
    required: true,
  },
});
const toggleState = ref(false);
const emits = defineEmits(["edit", "copy", "delete"]);

function handleEdit() {
  emits("edit", props._id);
}
function handleCopy() {
  emits("copy", props._id);
}
function handleDelete() {
  emits("delete", props._id);
}
</script>

<template>
  <div>
    <DropdownMenuRoot v-model:open="toggleState">
      <DropdownMenuTrigger
        class="rounded-lg border border-transparent px-1 text-base-300 hover:border-base-500/50 hover:text-base-100"
      >
        <Icon name="solar:menu-dots-bold" />
      </DropdownMenuTrigger>
      <DropdownMenuPortal>
        <DropdownMenuContent
          class="min-w-fit space-y-2 rounded-md border border-base-500/50 bg-base-default/40 px-2 py-2 pr-4 text-sm text-base-100 outline-none backdrop-blur"
          :side-offset="5"
        >
          <DropdownMenuItem
            class="hover:cursor-pointer hover:text-white"
            @click="handleEdit"
          >
            <Icon name="solar:pen-new-square-linear" /> Edit
          </DropdownMenuItem>
          <DropdownMenuItem
            class="hover:cursor-pointer hover:text-white"
            @click="handleCopy"
          >
            <Icon name="solar:copy-linear" /> Copy
          </DropdownMenuItem>
          <DropdownMenuItem
            @click="handleDelete"
            class="text-red-500/80 hover:cursor-pointer hover:text-red-500"
          >
            <Icon name="solar:trash-bin-trash-bold" /> Delete
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenuPortal>
    </DropdownMenuRoot>
  </div>
</template>
