<template>
  <div class="flex items-center gap-4 pb-3">
    <slot> </slot>
  </div>
</template>
