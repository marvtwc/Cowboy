<script setup lang="ts">
import { useEmployeeStore } from "~/stores/employees";
import { useCustomerStore } from "~/stores/customers";
import { type UserModel } from "~/server/utils/types/types";
const employeeStore = useEmployeeStore();
const customerStore = useCustomerStore();
const { modifyEmployee, getEmployees } = employeeStore;
const { selectedEmployee, showModifyDialog } = storeToRefs(employeeStore);
const { getCustomersWithId } = customerStore;
const employee = ref<UserModel>(
  selectedEmployee.value
    ? selectedEmployee.value
    : {
        name: "",
        email: "",
        username: "",
        password: "",
        access: 0,
        customers: [],
      },
);
const employeeCustomers = ref([]);
if (employee.value._id) {
  employeeCustomers.value = await getCustomersWithId(employee.value._id);
}
const selectedCustomers = ref<CustomerModel[]>(
  employeeCustomers ? employeeCustomers : [],
);

watch(
  () => selectedEmployee,
  async () => {
    if (!selectedEmployee.value) return;
    employee.value = selectedEmployee.value;
    if (employee.value._id) {
      employeeCustomers.value = await getCustomersWithId(employee.value._id);
      selectedCustomers.value = employeeCustomers.value;
    }
  },
  { deep: true },
);
async function handleSave() {
  if (!employee.value || !employee.value._id) return;
  const id = employee.value._id;
  const payload = {
    employee_id: id,
    employee: employee.value,
  };
  const data = await modifyEmployee(payload);
  if (data) {
    await getEmployees();
    showModifyDialog.value = false;
  }
}

const selectedCustomer = ref<CustomerModel | null>(null);
function handleCustomerSelected(customer: CustomerModel) {
  selectedCustomer.value = customer;
}
function selectCustomer() {
  if (!selectedCustomer.value) return;

  if (
    !selectedCustomers.value.find((c) => c._id === selectedCustomer.value._id)
  ) {
    selectedCustomers.value.push(selectedCustomer.value);
  }
}

function removeCustomer(customer: CustomerModel) {
  selectedCustomers.value = selectedCustomers.value.filter(
    (c) => c._id !== customer._id,
  );
}
</script>
<template>
  <BaseDialog :open="showModifyDialog" title="Edit Contractor">
    <div class="space-y-4">
      <div class="space-y-2">
        <fieldset class="flex flex-col gap-1">
          <label for="name">Name</label>
          <input id="name" type="text" v-model="employee.name" />
        </fieldset>
        <fieldset class="flex flex-col gap-1">
          <label for="email">Email</label>
          <input id="email" type="text" v-model="employee.email" />
        </fieldset>
        <fieldset class="flex flex-col gap-1">
          <label for="username">Username</label>
          <input id="username" type="text" v-model="employee.username" />
        </fieldset>
        <fieldset class="flex flex-col gap-1">
          <label for="password">Password</label>
          <input id="password" type="text" v-model="employee.password" />
        </fieldset>
        <fieldset class="flex flex-col gap-1">
          <label for="access">Access</label>
          <input id="access" type="text" v-model="employee.access" />
        </fieldset>
        <fieldset class="flex flex-col gap-1">
          <label for="customers">Customers</label>
          <div class="flex items-center gap-2">
            <CustomerCombo class="w-full" @update="handleCustomerSelected" />
            <button
              @click="selectCustomer"
              class="rounded-sm border border-white/10 bg-blue-600/80 px-4 text-white shadow-[0_2px_8px] shadow-blue-500/10"
            >
              Add
            </button>
          </div>
        </fieldset>
        <div
          v-if="selectedCustomers.length > 0"
          class="flex max-h-40 flex-col gap-2 overflow-y-auto rounded-sm border border-base-500/50 bg-base-600 pb-2 text-sm"
        >
          <div class="sticky top-0 flex justify-between bg-base-700 px-2 py-1">
            <div class="flex grow items-center gap-2">
              <span class="basis-1/4">Name</span>
              <span class="basis-1/4">City, State</span>
              <span class="">Note</span>
            </div>
            <Icon class="hidden text-transparent" name="mdi:close" />
          </div>
          <div
            class="flex justify-between px-2"
            v-for="customer in selectedCustomers"
          >
            <div class="flex grow items-center gap-2">
              <span class="basis-1/4">{{ customer.name }}</span>
              <span class="basis-1/4"
                >{{ customer.city }}, {{ customer.state }}</span
              >
              <span class="">{{ customer.note }}</span>
            </div>
            <button @click="removeCustomer(customer)">
              <Icon name="mdi:close" @click="removeCustomer(customer)" />
            </button>
          </div>
        </div>
        <fieldset class="flex flex-col gap-1">
          <label for="note">Note (Optional)</label>
          <textarea
            id="note"
            cols="30"
            rows="4"
            v-model="employee.note"
          ></textarea>
        </fieldset>
      </div>
      <div class="space-x-4 text-right">
        <button class="text-base-300" @click="showModifyDialog = false">
          Cancel
        </button>
        <button
          class="rounded-sm border border-white/10 bg-green-600/80 px-4 py-1 text-white shadow-[0_2px_8px] shadow-green-500/10"
          @click="handleSave"
        >
          Save
        </button>
      </div>
    </div>
  </BaseDialog>
</template>
