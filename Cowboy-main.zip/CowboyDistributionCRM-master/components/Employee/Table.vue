<script setup lang="ts">
import TableActions from "~/components/Table/Actions.vue";
import { useEmployeeStore } from "~/stores/employees";
const employeeStore = useEmployeeStore();
const { getEmployees, deleteEmployee } = employeeStore;
const { selectedEmployee, employees, showModifyDialog } =
  storeToRefs(employeeStore);
await getEmployees();

const employeesColumns = [
  {
    accessorKey: "name",
    header: "Name",
  },
  {
    accessorKey: "email",
    header: "Email",
  },
  {
    accessorKey: "username",
    header: "Username",
  },
  {
    accessorKey: "access",
    header: "Access",
  },
  {
    accessorKey: "note",
    header: "Note",
  },
  {
    accessorKey: " ",
    header: " ",
    cell: ({ row }) => {
      return h(TableActions, {
        _id: row.original._id,
        onEdit: (id: string) => {
          selectedEmployee.value = employees.value.find(
            (employee) => employee._id === id,
          );
          showModifyDialog.value = true;
        },
        onDelete: async (id: string) => {
          await deleteEmployee(id);
          await getEmployees();
        },
      });
    },
  },
];
</script>
<template>
  <div>
    <Table
      class="h-[calc(100vh-12rem)]"
      v-if="employees"
      :columns="employeesColumns"
      :data="employees"
    />
  </div>
</template>
