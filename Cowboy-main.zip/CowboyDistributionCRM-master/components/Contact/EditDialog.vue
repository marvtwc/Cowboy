<script setup lang="ts">
import { useCustomerStore } from "#imports";
import { type CustomerModel } from "~/server/utils/types/types";
const customerStore = useCustomerStore();
const { modifyCustomer, getCustomers } = customerStore;
const { selectedCustomer, showModifyDialog } = storeToRefs(customerStore);
const customer = ref<CustomerModel>(
  selectedCustomer.value
    ? selectedCustomer.value
    : {
        name: "",
        address: "",
        city: "",
        state: "",
        zip: "",
        billing_address: "",
        billing_city: "",
        billing_state: "",
        billing_zip: "",
        margin: 0,
        note: "",
      },
);

watch(
  () => selectedCustomer,
  () => {
    if (!selectedCustomer.value) return;
    customer.value = selectedCustomer.value;
  },
  { deep: true },
);
async function handleSave() {
  if (!customer.value || !customer.value._id) return;
  const id = customer.value._id;
  delete customer.value.contacts;
  delete customer.value._id;
  delete customer.value.__v;
  const payload = {
    customer_id: id,
    customer: customer.value,
  };
  const data = await modifyCustomer(payload);
  if (data) {
    await getCustomers();
    showModifyDialog.value = false;
  }
}
</script>
<template>
  <BaseDialog
    :open="showModifyDialog"
    title="Edit Customer"
    :description="`ID ${customer._id}`"
  >
    <div class="space-y-4">
      <div class="space-y-2">
        <fieldset>
          <label for="name">Name</label>
          <input id="name" type="text" v-model="customer.name" />
        </fieldset>
        <fieldset>
          <label for="address">Address</label>
          <input id="address" type="text" v-model="customer.address" />
        </fieldset>
        <fieldset>
          <label for="city">City</label>
          <input id="city" type="text" v-model="customer.city" />
        </fieldset>
        <fieldset>
          <label for="state">State</label>
          <input id="state" type="text" v-model="customer.state" />
        </fieldset>
        <fieldset>
          <label for="zip">Zip</label>
          <input id="zip" type="text" v-model="customer.zip" />
        </fieldset>
        <fieldset>
          <label for="billing_address">Billing Address</label>
          <input
            id="billing_address"
            type="text"
            v-model="customer.billing_address"
          />
        </fieldset>
        <fieldset>
          <label for="billing_city">Billing City</label>
          <input
            id="billing_city"
            type="text"
            v-model="customer.billing_city"
          />
        </fieldset>
        <fieldset>
          <label for="billing_state">Billing State</label>
          <input
            id="billing_state"
            type="text"
            v-model="customer.billing_state"
          />
        </fieldset>
        <fieldset>
          <label for="billing_zip">Billing Zip</label>
          <input id="billing_zip" type="text" v-model="customer.billing_zip" />
        </fieldset>
        <fieldset>
          <label for="margin">Margin</label>
          <input id="margin" type="number" v-model="customer.margin" />
        </fieldset>
        <fieldset>
          <label for="note">Note</label>
          <input id="note" type="text" v-model="customer.note" />
        </fieldset>
      </div>
      <div class="space-x-4 text-right">
        <button class="text-base-300" @click="showModifyDialog = false">
          Cancel
        </button>
        <button
          class="rounded-md border border-green-400 px-4 py-1 text-green-400"
          @click="handleSave"
        >
          Save
        </button>
      </div>
    </div>
  </BaseDialog>
</template>
