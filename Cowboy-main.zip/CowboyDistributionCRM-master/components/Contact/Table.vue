<script setup lang="ts">
import { useContactStore } from "~/stores/contacts";
const contactStore = useContactStore();
const { getContacts, deleteContact } = contactStore;
const { selectedContact, contacts, showModifyDialog } =
  storeToRefs(contactStore);
await getContacts();

const contactsColumns = [
  {
    accessorKey: "name",
    header: "Name",
  },

  {
    accessorKey: "email",
    header: "Email",
  },
  {
    accessorKey: "phone_number",
    header: "Phone Number",
  },
  {
    accessorKey: "title",
    header: "Title",
  },
  {
    accessorKey: "note",
    header: "Note",
  },
];
</script>
<template>
  <div>
    <Table v-if="contacts" :columns="contactsColumns" :data="contacts" />
  </div>
</template>
