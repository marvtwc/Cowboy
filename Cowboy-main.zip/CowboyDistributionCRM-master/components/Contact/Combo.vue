<script setup lang="ts">
import { useContactStore } from "~/stores/contacts";
const { getContacts } = useContactStore();
await getContacts();
const { contacts, showCreateDialog } = storeToRefs(useContactStore());
function onCreateContact() {
  emit("createContact");
  showCreateDialog.value = true;
}

const emit = defineEmits(["createContact"]);
const v = ref("");
</script>

<template>
  <ComboboxRoot v-model="v" class="relative mt-1">
    <ComboboxAnchor
      class="flex rounded-md border border-base-500/50 bg-base-600 pr-2"
    >
      <ComboboxInput
        class="w-full !border-none !bg-transparent placeholder-base-300"
        placeholder="Find a contact"
        :value="v.name"
      />
      <ComboboxTrigger>
        <Icon name="mdi:chevron-down" class="h-4 w-4" />
      </ComboboxTrigger>
      <ComboboxCancel />
    </ComboboxAnchor>
    <ComboboxContent
      class="absolute z-10 mt-2 w-full rounded-md border border-base-500 bg-base-default px-5 py-3 text-base-200"
    >
      <ComboboxViewport>
        <button @click="onCreateContact" class="text-sm text-base-300">
          <Icon name="mdi:account-plus" />
          Create contact
        </button>
        <ComboboxSeparator class="my-2 h-px bg-base-500" />
        <ComboboxEmpty>
          <span>No contacts</span>
        </ComboboxEmpty>
        <ComboboxItem
          v-for="(option, index) in contacts"
          :key="index"
          :value="option"
        >
          <ComboboxItemIndicator>
            <Icon name="mdi:checkbox-marked" />
          </ComboboxItemIndicator>
          <span>{{ option }}</span>
        </ComboboxItem>
      </ComboboxViewport>
      <ComboboxArrow />
    </ComboboxContent>
  </ComboboxRoot>
</template>
s
