<script setup lang="ts">
import type { ContactModel } from "~/server/utils/types/types";
import { useContactStore } from "~/stores/contacts";
const contactStore = useContactStore();
const { addContact, getContacts } = contactStore;
const { showCreateDialog, selectedEntity } = storeToRefs(contactStore);

const emit = defineEmits(["close"]);

const contact = ref<ContactModel>(init());
function init(): ContactModel {
  return {
    name: "",
    email: "",
    phone_number: "",
    title: "",
    note: "",
  };
}
async function handleConfirm() {
  if (!contact.value || !selectedEntity.value) return;

  const payload: any = {
    contact: {
      ...contact.value,
    },
  };

  if (selectedEntity.value?.type === "customer") {
    payload["customer_id"] = selectedEntity.value._id;
  } else if (selectedEntity.value?.type === "vendor") {
    payload["vendor_id"] = selectedEntity.value._id;
  }

  const data = await addContact(payload);
  if (data) {
    await getContacts();
    contact.value = init();
    showCreateDialog.value = false;
    emit("close");
  }
}

function handleCancel() {
  showCreateDialog.value = false;
  emit("close");
}
</script>
<template>
  <BaseDialog title="Add Contact" :open="showCreateDialog">
    <div class="space-y-2">
      <div class="flex justify-between gap-2">
        <fieldset class="flex grow flex-col gap-1">
          <label for="name">Name</label>
          <input class="w-full" id="name" type="text" v-model="contact.name" />
        </fieldset>
        <fieldset class="flex grow flex-col gap-1">
          <label for="title">Title</label>
          <input
            class="w-full"
            id="title"
            type="text"
            v-model="contact.title"
          />
        </fieldset>
      </div>
      <fieldset class="flex flex-col gap-1">
        <label for="email">Email</label>
        <input id="email" type="email" v-model="contact.email" />
      </fieldset>
      <fieldset class="flex flex-col gap-1">
        <label for="phone">Phone</label>
        <input id="phone" type="tel" v-model="contact.phone_number" />
      </fieldset>
      <fieldset class="flex flex-col gap-1">
        <label for="note">Note (Optional)</label>
        <textarea
          id="note"
          cols="30"
          rows="4"
          v-model="contact.note"
        ></textarea>
      </fieldset>
    </div>
    <div class="flex justify-end gap-2 pt-4">
      <button @click="handleCancel" class="px-4 py-1 text-base-300">
        Cancel
      </button>
      <button
        @click="handleConfirm"
        class="rounded-sm border border-white/10 bg-green-600/80 px-4 py-1 text-white shadow-[0_2px_8px] shadow-green-500/10"
      >
        Create
      </button>
    </div>
  </BaseDialog>
</template>
