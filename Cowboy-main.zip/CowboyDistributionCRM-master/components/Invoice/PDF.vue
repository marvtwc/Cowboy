<script setup lang="ts">
const pdfOutput = ref("");
const pdfElement = ref("pdfElement");

async function handleCreatePDF() {
  pdfOutput.value = await useNuxtApp()
    .$html2pdf()
    .from(pdfElement.value)
    .outputPdf()
    .output("bloburi");
}

const pdfData = ref({
  name: "John Doe",
  age: 30,
  city: "New York",
});

onMounted(async () => {
  await handleCreatePDF();
});
definePageMeta({
  middleware: "auth",
});
</script>
<template>
  <div>
    <BasePageHeader page="Dashboard" />
    <div class="absolute -z-[99999]">
      <div ref="pdfElement">{{ pdfData }}</div>
    </div>
    <embed
      width="100%"
      height="100%"
      v-if="pdfOutput"
      id="pdfOutput"
      type="application/pdf"
      :src="pdfOutput"
    />
    <!-- <ContactCombo /> -->
    <!-- <BaseCombo @click="getContacts" :options="contacts" /> -->
    <!-- <ContactTable />
    <ContactEditDialog /> -->
    <!-- <ContactCreateDialog /> -->
  </div>
</template>
