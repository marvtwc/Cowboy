<script setup lang="ts">
defineEmits(["update"]);
defineProps({
  id: Number,
  category: String,
  active: Boolean,
});
</script>
<template>
  <button
    @click="$emit('update', id)"
    :class="
      active
        ? 'bg-base-default font-bold text-base-100'
        : 'bg-base-600/50 text-base-300'
    "
    class="w-full rounded border border-base-500/50 py-2"
  >
    {{ category }}
  </button>
</template>
