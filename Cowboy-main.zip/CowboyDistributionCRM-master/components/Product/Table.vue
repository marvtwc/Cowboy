<script setup lang="ts">
import TableActions from "~/components/Table/Actions.vue";
import { useProductStore } from "~/stores/products";
const productStore = useProductStore();
const { getProducts } = productStore;
const {
  categories,
  selectedCategoryIndex,
  selectedCategory,
  selectedProduct,
  hideTypeColumn,
  products,
  filteredProducts,
  showModifyDialog,
} = storeToRefs(productStore);
await getProducts();

const productsColumns = [
  {
    accessorKey: "part_number",
    header: "Part #",
  },
  {
    accessorKey: "product_name",
    header: "Name",
  },
  {
    accessorKey: "vendor_name",
    header: "Vendor",
  },
  {
    accessorKey: "type",
    header: "Type",
    enableHiding: true,
  },
  {
    accessorKey: "size",
    header: "Size",
  },
  {
    accessorKey: "unit_measure",
    header: "Unit",
  },
  {
    accessorKey: "amount_per_case",
    header: "Case",
    cell: ({ row }) => {
      return `$${formatWithCommas(row.original.amount_per_case)}`;
    },
  },
  {
    accessorKey: "cases_per_pallet",
    header: "Pallet",
    cell: ({ row }) => {
      return `$${formatWithCommas(row.original.amount_per_case)}`;
    },
  },
  {
    accessorKey: "pallet_per_truck",
    header: "Truck",
    cell: ({ row }) => {
      return `$${formatWithCommas(row.original.amount_per_case)}`;
    },
  },
  {
    accessorKey: "note",
    header: "Note",
  },
  {
    accessorKey: " ",
    header: " ",
    cell: ({ row }) => {
      return h(TableActions, {
        _id: row.original._id,
        onEdit: (id: string) => {
          selectedProduct.value = products.value.find(
            (product) => product._id === id,
          );
          showModifyDialog.value = true;
        },
        onDelete: async (id: string) => {
          await productStore.deleteProduct(id);
          await getProducts();
        },
      });
    },
  },
];
</script>
<template>
  <div class="space-y-2">
    <div class="flex flex-col gap-4">
      <div class="flex gap-2">
        <ProductCategoryButton
          class="max-w-36"
          @update="(index) => (selectedCategoryIndex = index)"
          v-for="category in categories"
          :category="category"
          :active="category === selectedCategory"
          :id="categories.indexOf(category)"
        />
      </div>
      <Table
        class="h-[calc(100vh-16rem)]"
        :data="filteredProducts"
        :columns="productsColumns"
        :hidden-columns="hideTypeColumn ? ['type'] : []"
      />
    </div>
  </div>
</template>
