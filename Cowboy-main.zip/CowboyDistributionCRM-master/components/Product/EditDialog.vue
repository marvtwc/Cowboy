<script setup lang="ts">
import { Schema } from "mongoose";
import { useProductStore, type SelectedProductType } from "~/stores/products";
const productStore = useProductStore();
const { modifyProduct } = productStore;
const { showCreateDialog, showModifyDialog, selectedProduct } =
  storeToRefs(productStore);
import { useVendorStore } from "~/stores/vendors";
const vendorStore = useVendorStore();
const { getVendors } = vendorStore;
const { comboOptions } = storeToRefs(vendorStore);
await getVendors();

const product = ref<SelectedProductType>(
  selectedProduct.value
    ? selectedProduct.value
    : {
        _id: "",
        part_number: "",
        product_name: "",
        type: "",
        size: "",
        unit_measure: "",
        amount_per_case: 0,
        cases_per_pallet: 0,
        pallet_per_truck: 0,
        cost_per_product: 0,
        note: "",
        vendor_owned: new Schema.Types.ObjectId(""),
        vendor_name: "",
      },
);

watch(
  () => selectedProduct,
  () => {
    if (!selectedProduct.value) return;
    product.value = selectedProduct.value;
  },
  { deep: true },
);
async function handleConfirm() {
  if (!product.value || !product.value._id) return;
  const id = product.value._id;
  const payload = {
    product_id: id,
    product: product.value,
  };
  const data = await modifyProduct(payload).then(async () =>
    productStore.getProducts(),
  );
  if (data) {
    showModifyDialog.value = false;
  }
}
</script>
<template>
  <BaseDialog
    :open="showModifyDialog"
    title="Edit Product"
    :description="`ID ${product._id}`"
  >
    <div class="space-y-2">
      <fieldset class="flex flex-col gap-1">
        <label for="product_number">Product #</label>
        <input id="product_number" type="text" v-model="product.part_number" />
      </fieldset>
      <fieldset class="flex flex-col gap-1">
        <label for="name">Name</label>
        <input id="name" type="text" v-model="product.product_name" />
      </fieldset>
      <fieldset class="flex flex-col gap-1">
        <label for="vendor">Vendor</label>
        <BaseCombo
          id="vendor"
          :options="comboOptions"
          @update="(value) => (product.vendor_owned = value._id)"
          class="w-full"
        />
      </fieldset>
      <div class="flex justify-between gap-2">
        <fieldset class="flex w-full flex-col gap-1">
          <label for="type">Type</label>
          <input class="w-full" id="type" type="text" v-model="product.type" />
        </fieldset>
        <fieldset class="flex flex-col gap-1">
          <label for="size">Size</label>
          <input class="w-full" id="size" type="text" v-model="product.size" />
        </fieldset>
        <fieldset class="flex flex-col gap-1">
          <label for="unit">Unit</label>
          <input
            class="w-full"
            id="unit"
            type="text"
            v-model="product.unit_measure"
          />
        </fieldset>
      </div>
      <div class="flex justify-between gap-2">
        <fieldset class="flex flex-col gap-1">
          <label for="cost">Cost</label>
          <input
            class="w-full"
            id="cost"
            type="number"
            v-model="product.cost_per_product"
          />
        </fieldset>
        <fieldset class="flex flex-col gap-1">
          <label for="case">Per Case</label>
          <input
            class="w-full"
            id="case"
            type="number"
            v-model="product.amount_per_case"
          />
        </fieldset>
        <fieldset class="flex flex-col gap-1">
          <label for="pallet">Per Pallet</label>
          <input
            class="w-full"
            id="pallet"
            type="number"
            v-model="product.cases_per_pallet"
          />
        </fieldset>
        <fieldset class="flex flex-col gap-1">
          <label for="truck">Per Truck</label>
          <input
            class="w-full"
            id="truck"
            type="number"
            v-model="product.pallet_per_truck"
          />
        </fieldset>
      </div>
      <fieldset class="flex flex-col gap-1">
        <label for="note">Note (Optional)</label>
        <textarea
          id="note"
          cols="30"
          rows="4"
          v-model="product.note"
        ></textarea>
      </fieldset>
    </div>
    <div class="flex justify-end gap-2 pt-4">
      <button @click="showModifyDialog = false" class="px-4 py-1 text-base-300">
        Cancel
      </button>
      <button
        @click="handleConfirm"
        class="rounded-sm border border-white/10 bg-green-600/80 px-4 py-1 text-white shadow-[0_2px_8px] shadow-green-500/10"
      >
        Create
      </button>
    </div>
  </BaseDialog>
</template>
