<script setup lang="ts">
const props = defineProps({
  product: {
    type: Object,
    required: true,
  },
});
const emit = defineEmits(["update"]);

const margin = ref(props.product.margin ? props.product.margin : 0);
const quantity = ref(0);

function increment(increment: boolean) {
  quantity.value = increment ? quantity.value + 1 : quantity.value - 1;
  if (quantity.value < 0) quantity.value = 0;
  emitProduct();
}

function emitProduct() {
  emit("update", {
    quantity: quantity.value,
    margin: margin.value,
    ...props.product,
  });
}
</script>
<template>
  <div
    class="flex h-36 w-48 flex-col rounded-md border border-base-500/50 bg-base-default/50 text-white"
  >
    <div class="grow items-center p-4 text-center">
      <p>{{ product["product_name"] }}</p>
      <p>#{{ product["part_number"] }}</p>
    </div>
    <div class="flex flex-col">
      <!-- <button @click="increment(false)">
        <Icon class="h-12 w-12" name="solar:minus-square-bold" />
      </button>
      <input
        class="w-full !border-none !bg-transparent text-center [appearance:textfield] [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:appearance-none"
        type="number"
        v-model="quantity"
        @change="emitProduct()"
      />
      <button @click="increment(true)">
        <Icon class="h-12 w-12" name="solar:add-square-bold" />
      </button> -->
      <fieldset class="flex gap-4 px-2">
        <label for="margin">Margin</label>
        <input
          type="number"
          class="w-full"
          v-model="margin"
          @change="emitProduct()"
        />
      </fieldset>
      <fieldset class="flex gap-4 px-2">
        <label for="quantity">Qty</label>
        <input
          type="number"
          class="w-full"
          v-model="quantity"
          @change="emitProduct()"
        />
      </fieldset>
    </div>
  </div>
</template>
