<script setup lang="ts">
import { useProductStore } from "~/stores/products";
import { useVendorStore } from "~/stores/vendors";
const productStore = useProductStore();
const vendorStore = useVendorStore();
const { addProduct, getProducts } = productStore;
const { showCreateDialog } = storeToRefs(productStore);
const { getVendors } = vendorStore;
const { comboOptions } = storeToRefs(vendorStore);
await getVendors();

const product = ref(init());
function init() {
  return {
    part_number: "",
    product_name: "",
    vendor_owned: "",
    type: "",
    size: "",
    unit_measure: "",
    amount_per_case: 0,
    cases_per_pallet: 0,
    pallet_per_truck: 0,
    cost_per_product: 0,
    note: "",
  };
}
async function handleConfirm() {
  if (!product) return;
  const data = await addProduct(product);
  if (data) {
    await getProducts();
    product.value = init();
    showCreateDialog.value = false;
  }
}

// Fix combo ui width issue
</script>
<template>
  <BaseDialog title="Add Product" :open="showCreateDialog">
    <div class="space-y-2">
      <fieldset class="flex flex-col gap-1">
        <label for="product_number">Product #</label>
        <input id="product_number" type="text" v-model="product.part_number" />
      </fieldset>
      <fieldset class="flex flex-col gap-1">
        <label for="name">Name</label>
        <input id="name" type="text" v-model="product.product_name" />
      </fieldset>
      <fieldset class="flex flex-col gap-1">
        <label for="vendor">Vendor</label>
        <BaseCombo
          id="vendor"
          :options="comboOptions"
          @update="(value) => (product.vendor_owned = value._id.toString())"
          class="w-full"
        />
      </fieldset>
      <div class="flex justify-between gap-2">
        <fieldset class="flex w-full flex-col gap-1">
          <label for="type">Type</label>
          <input class="w-full" id="type" type="text" v-model="product.type" />
        </fieldset>
        <fieldset class="flex flex-col gap-1">
          <label for="size">Size</label>
          <input class="w-full" id="size" type="text" v-model="product.size" />
        </fieldset>
        <fieldset class="flex flex-col gap-1">
          <label for="unit">Unit</label>
          <input
            class="w-full"
            id="unit"
            type="text"
            v-model="product.unit_measure"
          />
        </fieldset>
      </div>
      <div class="flex justify-between gap-2">
        <fieldset class="flex flex-col gap-1">
          <label for="cost">Cost</label>
          <input
            class="w-full"
            id="cost"
            type="number"
            v-model="product.cost_per_product"
          />
        </fieldset>
        <fieldset class="flex flex-col gap-1">
          <label for="case">Per Case</label>
          <input
            class="w-full"
            id="case"
            type="number"
            v-model="product.amount_per_case"
          />
        </fieldset>
        <fieldset class="flex flex-col gap-1">
          <label for="pallet">Per Pallet</label>
          <input
            class="w-full"
            id="pallet"
            type="number"
            v-model="product.cases_per_pallet"
          />
        </fieldset>
        <fieldset class="flex flex-col gap-1">
          <label for="truck">Per Truck</label>
          <input
            class="w-full"
            id="truck"
            type="number"
            v-model="product.pallet_per_truck"
          />
        </fieldset>
      </div>
      <fieldset class="flex flex-col gap-1">
        <label for="note">Note (Optional)</label>
        <textarea
          id="note"
          cols="30"
          rows="4"
          v-model="product.note"
        ></textarea>
      </fieldset>
    </div>
    <div class="flex justify-end gap-2 pt-4">
      <button @click="showCreateDialog = false" class="px-4 py-1 text-base-300">
        Cancel
      </button>
      <button
        @click="handleConfirm"
        class="rounded-sm border border-white/10 bg-green-600/80 px-4 py-1 text-white shadow-[0_2px_8px] shadow-green-500/10"
      >
        Create
      </button>
    </div>
  </BaseDialog>
</template>
