<script setup lang="ts">
import { formatWithCommas } from "~/utils/format";
import { useProductStore } from "~/stores/products";
const productStore = useProductStore();
const { getProducts } = productStore;
const { selectedProduct, showModifyDialog, showDeleteAlert } =
  storeToRefs(productStore);

const selectedProducts = defineModel({ default: [] });

const res = await getProducts();
const products = res?.value.map((product) => {
  return {
    ...product,
    quantity: 0,
    margin: 0,
  };
});

function onEdit(id: string) {
  if (!products) return;
  selectedProduct.value = products.value.find((product) => product._id === id);
  showModifyDialog.value = true;
}

function onDelete(id: string) {
  if (!products) return;
  selectedProduct.value = products.value.find((product) => product._id === id);
  showDeleteAlert.value = true;
}

function handleQuantityChange(product) {
  if (product.quantity <= 0) {
    selectedProducts.value = selectedProducts.value.filter(
      (selectedProduct) => selectedProduct._id !== product._id,
    );
  } else {
    const index = selectedProducts.value.findIndex(
      (selectedProduct) => selectedProduct._id === product._id,
    );
    if (index !== -1) {
      selectedProducts.value.splice(index, 1, { ...product });
    } else {
      selectedProducts.value.push(product);
    }
  }
}
</script>
<template>
  <div
    class="relative mx-auto w-full overflow-auto rounded-lg border border-base-500/50"
  >
    <div
      class="sticky top-0 grid grid-cols-10 bg-base-700/60 px-4 py-2 text-sm text-base-200"
    >
      <span class="col-span-1">Product </span>
      <span class="col-span-1">Type</span>
      <span class="col-span-2">Name</span>
      <span class="col-span-2">Vendor</span>
      <span class="col-span-1 text-center">Cost</span>
      <span class="col-span-1 text-center">Qty</span>
      <span class="col-span-1 text-center">Margin</span>
      <span class="col-span-1"></span>
    </div>
    <AccordionRoot class="bg-base-default" type="multiple" :collapsible="true">
      <template v-for="product in products" :key="product._id">
        <AccordionItem
          class="mt-px overflow-hidden border-b-base-500/50 bg-base-default first:mt-0 focus-within:relative focus-within:z-10 [&:not(:last-child)]:border-b"
          v-if="product._id"
          :value="product._id"
        >
          <AccordionHeader
            class="flex border-b-base-500/50 data-[state=open]:border-b"
          >
            <div
              class="group relative z-0 grid w-full cursor-default grid-cols-10 items-center gap-4 bg-base-default px-4 py-3 text-left text-[15px] leading-none outline-none"
            >
              <span class="col-span-1">#{{ product.part_number }}</span>
              <span class="col-span-1">{{ product.type }}</span>
              <span class="col-span-2">{{ product.product_name }}</span>
              <span class="col-span-2">{{ product.vendor_name }}</span>
              <span class="col-span-1 text-center"
                >${{ formatWithCommas(product.cost_per_product) }}</span
              >
              <input
                class="relative z-[999999] col-span-1"
                type="number"
                min="0"
                v-model="product.quantity"
                @input="handleQuantityChange(product)"
              />
              <input
                class="col-span-1"
                type="number"
                min="0"
                v-model="product.margin"
              />
              <AccordionTrigger class="col-span-1">
                <Icon name="mdi:chevron-down" />
              </AccordionTrigger>
            </div>
          </AccordionHeader>
          <AccordionContent class="overflow-hidden bg-base-600 text-[15px]">
            <div class="space-y-2 px-5 py-4">
              <!-- <p class="font-medium">Cost</p> -->
              <div
                class="grid grid-cols-5 items-center justify-between gap-4 text-center"
              >
                <div class="col-span-1 flex w-full flex-col">
                  <span class="text-sm text-base-300">Cases Per Pallet</span>
                  <span class="rounded-md bg-base-default text-center">{{
                    formatWithCommas(product.cases_per_pallet)
                  }}</span>
                </div>
                <div class="col-span-1 flex w-full flex-col">
                  <span class="text-sm text-base-300">Pallet Per Truck</span>
                  <span class="rounded-md bg-base-default text-center"
                    >${{ formatWithCommas(product.pallet_per_truck) }}</span
                  >
                </div>
                <div class="col-span-1 flex w-full flex-col">
                  <span class="text-sm text-base-300">Amount Per Case</span>
                  <span class="rounded-md bg-base-default text-center"
                    >${{ product.amount_per_case }}</span
                  >
                </div>
                <div class="col-span-1 flex w-full flex-col">
                  <span class="text-sm text-base-300">Size</span>
                  <span class="rounded-md bg-base-default text-center">{{
                    product.size
                  }}</span>
                </div>
                <div class="col-span-1 flex w-full flex-col">
                  <span class="text-sm text-base-300">Unit of Measure</span>
                  <span class="rounded-md bg-base-default text-center">{{
                    product.unit_measure
                  }}</span>
                </div>
              </div>
            </div>
            <div v-if="product.note" class="flex basis-1/4 flex-col px-5 pb-2">
              <span class="text-sm text-base-300">Note</span>
              <span class="bg-base-default p-2">{{ product.note }}</span>
            </div>
          </AccordionContent>
        </AccordionItem>
      </template>
    </AccordionRoot>
  </div>
</template>
