<script setup lang="ts">
import { Schema } from "mongoose";
import type { OrderModel } from "~/server/utils/types/types";
import { useOrderStore } from "~/stores/orders";
const orderStore = useOrderStore();
const { addOrder, getOrders } = orderStore;
const { showCreateDialog } = storeToRefs(orderStore);

const order = ref<OrderModel>(init());
function init(): OrderModel {
  return {
    customer: new Schema.Types.ObjectId(""),
    employee: new Schema.Types.ObjectId(""),
    invoices: [],
    quotes: [],
  };
}
async function handleConfirm() {
  if (!order) return;
  const data = await addOrder(order);
  if (data) {
    await getOrders();
    order.value = init();
    showCreateDialog.value = false;
  }
}
</script>
<template>
  <BaseDialog title="Add Order" :open="showCreateDialog">
    <div class="space-y-2">
      <fieldset>
        <label for="customer">Customer</label>
        <input id="customer" type="text" v-model="order.customer" />
      </fieldset>
      <fieldset>
        <label for="customer">Customer</label>
        <input id="customer" type="text" v-model="order.customer" />
      </fieldset>
      <div class="flex justify-end gap-2">
        <button @click="showCreateDialog = false" class="text-base-300">
          Cancel
        </button>
        <button @click="handleConfirm" class="text-green-400">Create</button>
      </div>
    </div>
  </BaseDialog>
</template>
