<script setup lang="ts">
import TableActions from "~/components/Table/Actions.vue";
import { NuxtLink } from "#components";
import { useOrderStore } from "~/stores/orders";
import { useCustomerStore } from "~/stores/customers";
const orderStore = useOrderStore();
const { getCustomer } = useCustomerStore();
const { getOrders } = orderStore;
const { selectedOrder, orders, showModifyDialog } = storeToRefs(orderStore);
// TODO: Get Employee ID from session
const { data } = useAuth();
await getOrders(data.value!.user!._id);

const searchValue = ref("");

const ordersColumns = [
  {
    accessorKey: "_id",
    header: "Id",
    cell: ({ row }) => {
      return h(
        NuxtLink,
        { to: `/orders/${row.original._id}` },
        {
          default: () => row.original._id,
        },
      );
    },
  },
  {
    accessorKey: "customer",
    header: "Customer",
    cell: ({ row }) => {
      return row.original.customer.name;
    },
  },
  {
    accessorKey: "customer",
    header: "Note",
    cell: ({ row }) => {
      return row.original.customer.note;
    },
  },
];
</script>
<template>
  <div>
    <Table
      class="h-[calc(100vh-12rem)]"
      :data="orders"
      :columns="ordersColumns"
      :search="searchValue"
    >
    </Table>
  </div>
</template>
