<script setup lang="ts">
import type { CustomerModel } from "~/server/utils/types/types";
import { useCustomerStore } from "~/stores/customers";
const customerStore = useCustomerStore();
const { addCustomer, getCustomers } = customerStore;
const { showCreateDialog } = storeToRefs(customerStore);

const customer = ref<CustomerModel>(init());
function init(): CustomerModel {
  return {
    name: "",
    address: "",
    city: "",
    state: "",
    zip: "",
    billing_address: "",
    billing_city: "",
    billing_state: "",
    billing_zip: "",
    margin: 0,
    note: "",
  };
}
async function handleConfirm() {
  if (!customer) return;
  const data = await addCustomer(customer);
  if (data) {
    await getCustomers();
    customer.value = init();
    showCreateDialog.value = false;
  }
}
</script>
<template>
  <BaseDialog title="Add Customer" :open="showCreateDialog">
    <div class="space-y-2">
      <fieldset class="flex flex-col gap-1">
        <label for="name">Name</label>
        <input id="name" type="text" v-model="customer.name" />
      </fieldset>
      <fieldset class="flex flex-col gap-1">
        <label for="address">Address</label>
        <input id="address" type="text" v-model="customer.address" />
      </fieldset>
      <div class="flex gap-2">
        <fieldset class="flex basis-2/4 flex-col gap-1">
          <label for="city">City</label>
          <input class="w-full" id="city" type="text" v-model="customer.city" />
        </fieldset>
        <fieldset class="flex basis-1/4 flex-col gap-1">
          <label for="state">State</label>
          <input
            class="w-full"
            id="state"
            type="text"
            v-model="customer.state"
          />
        </fieldset>
        <fieldset class="flex basis-1/4 flex-col gap-1">
          <label for="zip">Zip</label>
          <input class="w-full" id="zip" type="text" v-model="customer.zip" />
        </fieldset>
      </div>
      <fieldset class="flex flex-col gap-1">
        <label for="billing_address">Billing Address</label>
        <input
          id="billing_address"
          type="text"
          v-model="customer.billing_address"
        />
      </fieldset>
      <div class="flex gap-2">
        <fieldset class="flex basis-2/4 flex-col gap-1">
          <label for="billing_city">Billing City</label>
          <input
            class="w-full"
            id="billing_city"
            type="text"
            v-model="customer.billing_city"
          />
        </fieldset>
        <fieldset class="flex basis-1/4 flex-col gap-1">
          <label for="billing_state">Billing State</label>
          <input
            class="w-full"
            id="billing_state"
            type="text"
            v-model="customer.billing_state"
          />
        </fieldset>
        <fieldset class="flex basis-1/4 flex-col gap-1">
          <label for="billing_zip">Billing Zip</label>
          <input
            class="w-full"
            id="billing_zip"
            type="text"
            v-model="customer.billing_zip"
          />
        </fieldset>
      </div>
      <div class="flex items-center gap-2">
        <fieldset class="basis-2/3">
          <div class="flex flex-col">
            <label for="contacts">Contacts</label>
            <ContactCombo @create-contact="" />
          </div>
        </fieldset>
        <fieldset class="flex basis-1/3 flex-col gap-1">
          <label for="margin">Margin</label>
          <input
            class="w-full"
            id="margin"
            type="number"
            v-model="customer.margin"
          />
        </fieldset>
        <div class="flex flex-col">
          <div v-for="contact in contacts">
            <span>Name {{ contact.name }}</span>
            <span>Email {{ contact.email }}</span>
            <span>Phone {{ contact.phone_number }}</span>
            <span>Title {{ contact.title }}</span>
            <span>Note {{ contact.note }}</span>
          </div>
        </div>
      </div>
      <fieldset class="flex flex-col gap-1">
        <label for="note">Note (Optional)</label>
        <textarea
          id="note"
          cols="30"
          rows="4"
          v-model="customer.note"
        ></textarea>
      </fieldset>
    </div>
    <div class="flex justify-end gap-2 pt-4">
      <button @click="showCreateDialog = false" class="px-4 py-1 text-base-300">
        Cancel
      </button>
      <button
        @click="handleConfirm"
        class="rounded-sm border border-white/10 bg-green-600/80 px-4 py-1 text-white shadow-[0_2px_8px] shadow-green-500/10"
      >
        Create
      </button>
    </div>
  </BaseDialog>
</template>
