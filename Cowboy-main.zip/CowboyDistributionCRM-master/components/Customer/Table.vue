<script setup lang="ts">
import TableActions from "~/components/Table/Actions.vue";
import { useCustomerStore } from "~/stores/customers";
const customerStore = useCustomerStore();
const { getCustomers, deleteCustomer } = customerStore;
const { selectedCustomer, customers, showModifyDialog } =
  storeToRefs(customerStore);
await getCustomers();

const customersColumns = [
  {
    accessorKey: "name",
    header: "Name",
  },
  {
    accessorKey: "address",
    header: "Address",
    cell: ({ row }) => {
      return row.original.address + ", " + row.original.city;
    },
  },
  {
    accessorKey: "billing_address",
    header: "Billing",
    cell: ({ row }) => {
      return row.original.billing_address + ", " + row.original.city;
    },
  },
  {
    accessorKey: "margin",
    header: "Margin",
  },
  {
    accessorKey: "note",
    header: "Note",
  },
  {
    accessorKey: " ",
    header: " ",
    cell: ({ row }) => {
      return h(TableActions, {
        _id: row.original._id,
        onEdit: (id: string) => {
          selectedCustomer.value = customers.value.find(
            (customer) => customer._id === id,
          );
          showModifyDialog.value = true;
        },
        onDelete: async (id: string) => {
          await deleteCustomer(id);
          await getCustomers();
        },
      });
    },
  },
];
</script>
<template>
  <div>
    <Table
      class="h-[calc(100vh-12rem)]"
      v-if="customers"
      :columns="customersColumns"
      :data="customers"
    />
  </div>
</template>
