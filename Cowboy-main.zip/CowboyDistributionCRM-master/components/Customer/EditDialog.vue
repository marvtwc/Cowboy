<script setup lang="ts">
import { useCustomerStore } from "#imports";
import { type CustomerModel } from "~/server/utils/types/types";
const customerStore = useCustomerStore();
const { modifyCustomer, getCustomers } = customerStore;
const { selectedCustomer, showModifyDialog } = storeToRefs(customerStore);
const customer = ref<CustomerModel>(
  selectedCustomer.value
    ? selectedCustomer.value
    : {
        name: "",
        address: "",
        city: "",
        state: "",
        zip: "",
        billing_address: "",
        billing_city: "",
        billing_state: "",
        billing_zip: "",
        margin: 0,
        note: "",
      },
);

watch(
  () => selectedCustomer,
  () => {
    if (!selectedCustomer.value) return;
    customer.value = selectedCustomer.value;
  },
  { deep: true },
);
async function handleConfirm() {
  if (!customer.value || !customer.value._id) return;
  const id = customer.value._id;
  delete customer.value.contacts;
  delete customer.value._id;
  delete customer.value.__v;
  const payload = {
    customer_id: id,
    customer: customer.value,
  };
  const data = await modifyCustomer(payload);
  if (data) {
    await getCustomers();
    showModifyDialog.value = false;
  }
}
</script>
<template>
  <BaseDialog :open="showModifyDialog" title="Edit Customer">
    <div class="space-y-4">
      <div class="space-y-2">
        <fieldset class="flex flex-col gap-1">
          <label for="name">Name</label>
          <input id="name" type="text" v-model="customer.name" />
        </fieldset>
        <div class="flex gap-2">
          <fieldset class="flex basis-2/4 flex-col gap-1">
            <label for="city">City</label>
            <input
              class="w-full"
              id="city"
              type="text"
              v-model="customer.city"
            />
          </fieldset>
          <fieldset class="flex basis-1/4 flex-col gap-1">
            <label for="state">State</label>
            <input
              class="w-full"
              id="state"
              type="text"
              v-model="customer.state"
            />
          </fieldset>
          <fieldset class="flex basis-1/4 flex-col gap-1">
            <label for="zip">Zip</label>
            <input class="w-full" id="zip" type="text" v-model="customer.zip" />
          </fieldset>
        </div>
        <fieldset class="flex flex-col gap-1">
          <label for="billing_address">Billing Address</label>
          <input
            id="billing_address"
            type="text"
            v-model="customer.billing_address"
          />
        </fieldset>
        <div class="flex gap-2">
          <fieldset class="flex basis-2/4 flex-col gap-1">
            <label for="billing_city">Billing City</label>
            <input
              class="w-full"
              id="billing_city"
              type="text"
              v-model="customer.billing_city"
            />
          </fieldset>
          <fieldset class="flex basis-1/4 flex-col gap-1">
            <label for="billing_state">Billing State</label>
            <input
              class="w-full"
              id="billing_state"
              type="text"
              v-model="customer.billing_state"
            />
          </fieldset>
          <fieldset class="flex basis-1/4 flex-col gap-1">
            <label for="billing_zip">Billing Zip</label>
            <input
              class="w-full"
              id="billing_zip"
              type="text"
              v-model="customer.billing_zip"
            />
          </fieldset>
        </div>
        <fieldset class="flex flex-col gap-1">
          <label for="margin">Margin</label>
          <input id="margin" type="number" v-model="customer.margin" />
        </fieldset>
        <fieldset class="flex flex-col gap-1">
          <label for="note">Note (Optional)</label>
          <textarea
            id="note"
            cols="30"
            rows="4"
            v-model="customer.note"
          ></textarea>
        </fieldset>
      </div>
    </div>
    <div class="flex justify-end gap-2 pt-4">
      <button @click="showModifyDialog = false" class="px-4 py-1 text-base-300">
        Cancel
      </button>
      <button
        @click="handleConfirm"
        class="rounded-sm border border-white/10 bg-green-600/80 px-4 py-1 text-white shadow-[0_2px_8px] shadow-green-500/10"
      >
        Create
      </button>
    </div>
  </BaseDialog>
</template>
