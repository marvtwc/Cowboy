<script setup lang="ts">
import {
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogOverlay,
  DialogPortal,
  DialogRoot,
  DialogTitle,
} from "radix-vue";

const props = defineProps({
  title: String,
  description: String,
  open: Boolean,
});
</script>

<template>
  <DialogRoot :open="open">
    <DialogPortal>
      <DialogOverlay class="fixed inset-0 z-30 bg-black/70 backdrop-blur-sm" />
      <DialogContent
        class="fixed left-[50%] top-[50%] z-[100] max-h-[85vh] w-[90vw] max-w-[800px] translate-x-[-50%] translate-y-[-50%] rounded-[6px] border border-base-500/50 bg-base-default p-[25px] text-base-100 shadow-[hsl(206_22%_7%_/_35%)_0px_10px_38px_-10px,_hsl(206_22%_7%_/_20%)_0px_10px_20px_-15px] focus:outline-none"
      >
        <DialogTitle class="pb-4 text-xl">
          {{ title }}
        </DialogTitle>
        <DialogDescription class="text-base-300">
          {{ description }}
        </DialogDescription>
        <slot></slot>
        <DialogClose />
      </DialogContent>
    </DialogPortal>
  </DialogRoot>
</template>
