<script setup lang="ts">
import {
  ComboboxAnchor,
  ComboboxArrow,
  ComboboxCancel,
  ComboboxContent,
  ComboboxEmpty,
  ComboboxGroup,
  ComboboxInput,
  ComboboxItem,
  ComboboxItemIndicator,
  ComboboxRoot,
  ComboboxSeparator,
  ComboboxTrigger,
  ComboboxViewport,
} from "radix-vue";
defineEmits(["update"]);

export interface Option {
  _id: string | number;
  name: string;
  [key: string]: any;
}

const { options } = defineProps<{ options: Array<Option> }>();

const v = ref<Option>(options[0]);
</script>

<template>
  <ComboboxRoot
    v-model="v"
    @update:model-value="$emit('update', v)"
    class="relative"
  >
    <ComboboxAnchor
      class="flex rounded-md border border-base-500/50 bg-base-600 px-2 py-1"
    >
      <ComboboxInput
        class="w-full !border-none !bg-transparent"
        placeholder="Placeholder..."
        :value="v.name"
      />
      <ComboboxTrigger>
        <Icon name="radix-icons:chevron-down" class="h-4 w-4" />
      </ComboboxTrigger>
    </ComboboxAnchor>

    <ComboboxContent
      class="absolute z-10 mt-2 w-full rounded-md border border-base-500 bg-base-default px-5 py-3 text-base-200"
    >
      <ComboboxViewport class="p-[5px]">
        <ComboboxEmpty class="py-2 text-center text-xs font-medium" />

        <ComboboxGroup>
          <ComboboxItem
            v-for="option in options"
            :key="option.id"
            :value="option"
          >
            <ComboboxItemIndicator>
              <Icon name="radix-icons:check" />
            </ComboboxItemIndicator>
            <span>
              {{ option.name }}
            </span>
          </ComboboxItem>
        </ComboboxGroup>
      </ComboboxViewport>
    </ComboboxContent>
  </ComboboxRoot>
</template>
