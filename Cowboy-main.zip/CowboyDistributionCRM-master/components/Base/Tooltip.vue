<script setup lang="ts">
const props = defineProps({
  tooltipText: String,
  enabled: Boolean,
  direction: { type: String, default: "bottom" },
});

const isTooltipVisible = ref(false);
const showTooltip = (value: boolean) => {
  if (props.enabled) {
    isTooltipVisible.value = value;
  } else {
    isTooltipVisible.value = false;
  }
};
</script>
<template>
  <span class="relative">
    <span
      @mouseover="showTooltip(true)"
      @mouseleave="showTooltip(false)"
      @click="showTooltip(false)"
    >
      <slot> </slot>
    </span>
    <Transition>
      <div
        v-show="isTooltipVisible"
        :class="{
          'top-0 -translate-y-full': direction === 'top',
        }"
        class="absolute z-[999] translate-x-8 transition delay-500 duration-75 ease-in"
      >
        <div
          :class="{
            'rounded-bl-sm': direction === 'top',
            'rounded-tl-sm': direction === 'bottom',
          }"
          class="rounded-2xl border border-base-500/50 bg-base-default px-4 py-2"
        >
          <p class="text-sm">{{ tooltipText }}</p>
        </div>
      </div>
    </Transition>
  </span>
</template>
<style scoped>
.v-enter-active,
.v-leave-active {
  transition-property: opacity;
  transition-duration: 0.15s;
  transition-timing-function: ease-in;
  transition-delay: 500ms;
}
.v-leave-active {
  transition-delay: 0s;
}

.v-enter-from,
.v-leave-to {
  opacity: 0;
}
</style>
