<script setup lang="ts">
import type { InputHTMLAttributes } from "vue";
import { computed } from "vue";
import { errorMessages } from "vue/compiler-sfc";
// Define the allowed input types
type InputTypes = Extract<
  InputHTMLAttributes["type"],
  "text" | "number" | "email" | "password" | "tel" | "url"
>;
// Input component properties
interface InputProps {
  label?: string;
  type?: InputTypes;
  placeholder?: string;
  disabled?: boolean;
  readonly?: boolean;
  clearable?: boolean;
  errorMessage?: string;
  error?: boolean;
}
// Default props with unique ID generation
const props = withDefaults(defineProps<InputProps>(), {
  label: "",
  type: "text",
  placeholder: "",
  errorMessage: "",
});
const emit = defineEmits(["update:modelValue"]);
const modelValue = defineModel<{ modelValue: InputHTMLAttributes["value"] }>();
const showClearable = computed(
  () => props.clearable && modelValue.value && !props.disabled,
);
// Function to clear the input
function clearInput() {
  if (!props.clearable) return;
  modelValue.value = undefined;
}
</script>
<template>
  <div class="flex w-full flex-col">
    <!-- Label -->
    <label class="" v-if="label">{{ label }}</label>
    <!-- Input field with clear and error handling -->
    <div class="relative flex w-full bg-base-100">
      <input
        v-model="modelValue"
        :type="type"
        class="w-full rounded-sm !bg-none px-2 py-[2px] text-black focus:outline-none"
        :class="{
          '': showClearable,
          '': error,
        }"
        :placeholder="placeholder"
        :disabled="disabled"
        :readonly="readonly"
      />
      <!-- Clear icon -->
      <Icon
        v-if="showClearable"
        name="mdi:close"
        class="text-black"
        @click="clearInput"
      />
    </div>
    <!-- Error message -->
    <span v-if="errorMessages" class="text-red-500"> {{ errorMessage }}</span>
  </div>
</template>
