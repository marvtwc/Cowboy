<script setup lang="ts">
const { signOut } = useAuth();
import { breakpointsTailwind, useBreakpoints } from "@vueuse/core";
const breakpoints = useBreakpoints(breakpointsTailwind);
// const isTablet = breakpoints.smaller("lg");
const isSidebarClosed = ref(false);
const handleToggleSidebar = () => {
  isSidebarClosed.value = !isSidebarClosed.value;
};
</script>

<template>
  <div class="flex-none lg:p-4">
    <div
      :class="isSidebarClosed ? 'w-fit ' : ' '"
      class="flex h-full w-64 flex-col gap-4 border border-base-500/50 bg-base-default p-4 shadow-lg drop-shadow-lg lg:max-w-xs lg:rounded-lg"
    >
      <div class="flex items-center justify-between">
        <p :class="isSidebarClosed ? 'hidden' : ''" class="px-2 font-semibold">
          Oxidized CRM
        </p>
        <BaseTooltip :enabled="true" tooltip-text="Toggle Sidebar">
          <button @click="handleToggleSidebar()" class="px-2">
            <Icon
              :name="
                isSidebarClosed
                  ? 'solar:sidebar-minimalistic-bold'
                  : 'solar:sidebar-minimalistic-linear'
              "
            />
          </button>
        </BaseTooltip>
      </div>
      <BaseSeperator />
      <ul class="flex flex-col gap-1">
        <BaseTooltip :enabled="isSidebarClosed" tooltip-text="Dashboard">
          <BaseNavbarLink to="/">
            <Icon name="solar:command-linear" />
            <span :class="isSidebarClosed ? 'hidden' : ''">Dashboard</span>
          </BaseNavbarLink>
        </BaseTooltip>
        <BaseTooltip :enabled="isSidebarClosed" tooltip-text="Analytics">
          <BaseNavbarLink to="/analytics">
            <Icon name="solar:pie-chart-2-linear" />
            <span :class="isSidebarClosed ? 'hidden' : ''">Analytics</span>
          </BaseNavbarLink>
        </BaseTooltip>
        <BaseTooltip :enabled="isSidebarClosed" tooltip-text="Orders">
          <BaseNavbarLink to="/orders">
            <Icon name="solar:checklist-bold" />
            <span :class="isSidebarClosed ? 'hidden' : ''">Orders</span>
          </BaseNavbarLink>
        </BaseTooltip>
      </ul>
      <BaseSeperator />
      <ul class="flex flex-col gap-1">
        <BaseTooltip :enabled="isSidebarClosed" tooltip-text="Products">
          <BaseNavbarLink to="/products">
            <Icon name="solar:box-linear" />
            <span :class="isSidebarClosed ? 'hidden' : ''">Products</span>
          </BaseNavbarLink>
        </BaseTooltip>
        <BaseTooltip :enabled="isSidebarClosed" tooltip-text="Vendors">
          <BaseNavbarLink to="/vendors">
            <Icon name="solar:shop-2-linear" \ />
            <span :class="isSidebarClosed ? 'hidden' : ''">Vendors</span>
          </BaseNavbarLink>
        </BaseTooltip>
        <BaseTooltip :enabled="isSidebarClosed" tooltip-text="Customers">
          <BaseNavbarLink to="/customers">
            <Icon name="solar:users-group-rounded-linear" />
            <span :class="isSidebarClosed ? 'hidden' : ''">Customers</span>
          </BaseNavbarLink>
        </BaseTooltip>
        <BaseTooltip :enabled="isSidebarClosed" tooltip-text="Contractors">
          <BaseNavbarLink to="/contractors">
            <Icon name="solar:user-id-linear" />
            <span :class="isSidebarClosed ? 'hidden' : ''">Contractors</span>
          </BaseNavbarLink>
        </BaseTooltip>
      </ul>
      <BaseSeperator />
      <ul class="flex grow flex-col justify-end gap-1">
        <BaseTooltip
          :enabled="isSidebarClosed"
          tooltip-text="Logout"
          direction="top"
        >
          <li class="text-base-200">
            <button @click="signOut()" class="flex items-center gap-2 px-2">
              <Icon name="solar:logout-linear" /><span
                :class="isSidebarClosed ? 'hidden' : ''"
                >Logout</span
              >
            </button>
          </li>
        </BaseTooltip>
      </ul>
    </div>
  </div>
</template>
