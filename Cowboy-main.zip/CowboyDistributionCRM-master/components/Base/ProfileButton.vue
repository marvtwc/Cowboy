<script setup lang="ts">
const { data } = useAuth();
</script>
<template>
  <div
    class="flex w-fit items-center gap-2 rounded-full border border-base-500/50 bg-base-default pr-6 align-middle"
  >
    <Icon name="solar:user-circle-bold" class="h-12 w-12" />
    <div class="flex min-w-16 flex-col">
      <p class="leading-4">{{ data?.user?.name }}</p>
      <p class="text-xs text-neutral-500">{{ data?.user?.access }}</p>
    </div>
    <!-- <Icon name="solar:alt-arrow-down-line-duotone" class="h-6 w-6" /> -->
  </div>
</template>
