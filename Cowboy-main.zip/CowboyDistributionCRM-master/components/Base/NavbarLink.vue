<script setup lang="ts">
const props = defineProps(["to"]);
const router = useRouter();
const isActive = computed(() => router.currentRoute.value.path === props.to);
</script>
<template>
  <li
    :class="isActive ? 'border-white/5 bg-gradient-to-b text-white' : ''"
    class="rounded-lg border border-transparent from-base-700 to-base-600/20 text-base-200 hover:border-white/5 hover:text-base-100"
  >
    <NuxtLink
      class="block space-x-2 px-2 py-2 tracking-wider text-inherit"
      :to="to"
    >
      <slot></slot>
    </NuxtLink>
  </li>
</template>
