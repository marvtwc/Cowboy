<script setup lang="ts">
import { cva, type VariantProps } from "class-variance-authority";

const button = cva(
  "flex items-center justify-center px-4 py-2 rounded-sm border focus:outline-none ",
  {
    variants: {
      intent: {
        primary: "bg-orange-500 border-orange-300/30 text-white",
        secondary: "bg-base-default border-base-300/10",
      },
      fullWidth: {
        true: "w-full",
        false: "w-fit",
      },
      size: {
        small: "text-sm",
        medium: "text-base",
        large: "text-lg",
      },
      defaultVariant: {
        intent: "primary",
        fitWidth: true,
      },
    },
  },
);

type ButtonProps = VariantProps<typeof button>;

withDefaults(
  defineProps<{
    intent: ButtonProps["intent"];
    size: ButtonProps["size"];
    fullWidth: ButtonProps["fullWidth"];
  }>(),
  {
    intent: "primary",
    size: "medium",
    fullWidth: false,
  },
);
</script>
<template>
  <button :class="button({ intent, size, fullWidth })"><slot /></button>
</template>
