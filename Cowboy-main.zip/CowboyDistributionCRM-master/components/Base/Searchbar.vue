<script setup lang="ts">
const emit = defineEmits(["update"]);
function handleChange(e: Event) {
  if (e.target) {
    if (e.target instanceof HTMLInputElement) {
      emit("update", e.target.value);
    }
  }
}
</script>
<template>
  <div
    class="flex w-full max-w-xs items-center gap-2 rounded-full border border-white/5 bg-base-600 px-2 py-1 text-base-500 transition duration-75 ease-in focus-within:border-white/10 focus-within:text-base-300 lg:max-w-md"
  >
    <Icon name="solar:magnifer-linear" />
    <input
      @input="(value) => handleChange(value)"
      type="text"
      placeholder="Search"
      class="w-full bg-transparent text-base-100 placeholder:text-base-500 focus:outline-none"
    />
  </div>
</template>
