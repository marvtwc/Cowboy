<template>
  <div
    class="h-[1px] w-full bg-gradient-to-r from-transparent via-neutral-100/10 to-transparent"
  ></div>
</template>
