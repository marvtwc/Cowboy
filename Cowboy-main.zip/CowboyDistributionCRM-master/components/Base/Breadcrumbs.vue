<script setup lang="ts">
const route = useRoute();
const breadcrumbs = computed(() => {
  const pathArray = route.path.split("/");
  pathArray.shift();
  const breadcrumbs = pathArray.reduce((breadcrumbArray, path, idx) => {
    breadcrumbArray.push({
      to: breadcrumbArray[idx - 1]
        ? "/" + breadcrumbArray[idx - 1].path + "/" + path
        : "/" + path,
      title: path,
    });
    return breadcrumbArray;
  }, []);
  return breadcrumbs;
});
</script>
<template>
  <ol class="flex">
    <li v-for="(item, i) in breadcrumbs.slice(0, -1)" :key="i" class="item">
      <nuxt-link :to="item.to" class="title">
        {{ item.title }}
      </nuxt-link>
      <Icon name="solar:alt-arrow-right-line-duotone" class="h-4 w-4" />
    </li>
  </ol>
</template>
