<script setup lang="ts">
defineProps({
  page: String,
});
</script>
<template>
  <div>
    <div class="flex items-center justify-between">
      <div class="flex items-center gap-6">
        <div class="flex flex-col">
          <h1 class="text-4xl font-extralight tracking-wide">{{ page }}</h1>
          <BaseBreadcrumbs />
        </div>
        <slot></slot>
      </div>
      <BaseProfileButton />
    </div>
    <BaseSeperator class="my-4" />
  </div>
</template>
